package com.stackroute.keepnote.dao;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.stackroute.keepnote.exception.CategoryNotFoundException;
import com.stackroute.keepnote.model.Category;

/*
 * This class is implementing the UserDAO interface. This class has to be annotated with 
 * @Repository annotation.
 * @Repository - is an annotation that marks the specific class as a Data Access Object, 
 * thus clarifying it's role.
 * @Transactional - The transactional annotation itself defines the scope of a single database 
 * 					transaction. The database transaction happens inside the scope of a persistence 
 * 					context.  
 * */
@Repository
public class CategoryDAOImpl implements CategoryDAO {

	/*
	 * Autowiring should be implemented for the SessionFactory.(Use
	 * constructor-based autowiring.
	 */
	@Autowired
	private SessionFactory sessionFactory;
	
	public CategoryDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	/*
	 * Create a new category
	 */
	@Override
	@Transactional
	public boolean createCategory(Category category) {
		try {
			sessionFactory.getCurrentSession().save(category);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/*
	 * Remove an existing category
	 */
	@Override
	@Transactional
	public boolean deleteCategory(int categoryId) {
		try {
			sessionFactory.getCurrentSession().delete(getCategoryById(categoryId));
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/*
	 * Update an existing category
	 */
	@Override
	@Transactional
	public boolean updateCategory(Category category) {
		try {
			sessionFactory.getCurrentSession().update(category);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/*
	 * Retrieve details of a specific category
	 */
	public Category getCategoryById(int categoryId) throws CategoryNotFoundException {
		Category category;

		try {
			category = sessionFactory.getCurrentSession().get(Category.class, categoryId);
		} catch (Exception e) {
			category = null;
		}

		if (category == null)
			throw new CategoryNotFoundException(String.format("Category with ID {0} not found", categoryId));

		return category;
	}

	/*
	 * Retrieve details of all categories by userId
	 */
	public List<Category> getAllCategoryByUserId(String userId) {
		List<Category> categories;

		try {
			categories = sessionFactory.getCurrentSession().createCriteria(Category.class).list();
		} catch (Exception e) {
			categories = new ArrayList<Category>();
		}
		return categories;
	}

}
