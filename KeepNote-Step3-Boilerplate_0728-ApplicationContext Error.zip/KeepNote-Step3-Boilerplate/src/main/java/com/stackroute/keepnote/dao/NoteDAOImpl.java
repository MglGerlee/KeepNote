package com.stackroute.keepnote.dao;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.stackroute.keepnote.exception.NoteNotFoundException;
import com.stackroute.keepnote.model.Note;

/*
 * This class is implementing the UserDAO interface. This class has to be annotated with 
 * @Repository annotation.
 * @Repository - is an annotation that marks the specific class as a Data Access Object, 
 * thus clarifying it's role.
 * @Transactional - The transactional annotation itself defines the scope of a single database 
 * 					transaction. The database transaction happens inside the scope of a persistence 
 * 					context.  
 * */
@Repository
public class NoteDAOImpl implements NoteDAO {

	/*
	 * Autowiring should be implemented for the SessionFactory.(Use
	 * constructor-based autowiring.
	 */
	@Autowired
	private SessionFactory sessionFactory;
	
	public NoteDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	/*
	 * Create a new note
	 */
	@Override
	@Transactional
	public boolean createNote(Note note) {
		try {
			sessionFactory.getCurrentSession().save(note);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/*
	 * Remove an existing note
	 */
	@Override
	@Transactional
	public boolean deleteNote(int noteId) {
		try {
			sessionFactory.getCurrentSession().delete(getNoteById(noteId));
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	/*
	 * Retrieve details of all notes by userId
	 */
	@Override
	@Transactional
	public List<Note> getAllNotesByUserId(String userId) {
		List<Note> notes;

		try {
			notes = sessionFactory.getCurrentSession().createCriteria(Note.class).list();
		} catch (Exception e) {
			notes = new ArrayList<Note>();
		}
		return notes;
	}

	/*
	 * Retrieve details of a specific note
	 */
	@Override
	@Transactional
	public Note getNoteById(int noteId) throws NoteNotFoundException {
		Note note;

		try {
			note = sessionFactory.getCurrentSession().get(Note.class, noteId);
		} catch (Exception e) {
			note = null;
		}

		if (note == null)
			throw new NoteNotFoundException(String.format("Note with ID {0} not found", noteId));

		return note;
	}

	/*
	 * Update an existing note
	 */
	@Override
	@Transactional
	public boolean UpdateNote(Note note) {
		try {
			sessionFactory.getCurrentSession().update(note);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

}
