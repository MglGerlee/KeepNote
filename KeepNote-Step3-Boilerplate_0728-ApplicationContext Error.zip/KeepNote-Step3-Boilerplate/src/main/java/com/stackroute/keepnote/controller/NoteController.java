package com.stackroute.keepnote.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.stackroute.keepnote.exception.CategoryNotFoundException;
import com.stackroute.keepnote.exception.NoteNotFoundException;
import com.stackroute.keepnote.exception.ReminderNotFoundException;
import com.stackroute.keepnote.model.Note;
import com.stackroute.keepnote.service.NoteService;

/*
 * As in this assignment, we are working with creating RESTful web service, hence annotate
 * the class with @RestController annotation.A class annotated with @Controller annotation
 * has handler methods which returns a view. However, if we use @ResponseBody annotation along
 * with @Controller annotation, it will return the data directly in a serialized 
 * format. Starting from Spring 4 and above, we can use @RestController annotation which 
 * is equivalent to using @Controller and @ResposeBody annotation
 */
@RestController
public class NoteController {

	/*
	 * Autowiring should be implemented for the NoteService. (Use Constructor-based
	 * autowiring) Please note that we should not create any object using the new
	 * keyword
	 */
	private NoteService noteService;
	
	public NoteController(NoteService noteService) {
		this.noteService = noteService;
	}

	/*
	 * Define a handler method which will create a specific note by reading the
	 * Serialized object from request body and save the note details in a Note table
	 * in the database.Handle ReminderNotFoundException and
	 * CategoryNotFoundException as well. please note that the loggedIn userID
	 * should be taken as the createdBy for the note.This handler method should
	 * return any one of the status messages basis on different situations: 1.
	 * 201(CREATED) - If the note created successfully. 2. 409(CONFLICT) - If the
	 * noteId conflicts with any existing user3. 401(UNAUTHORIZED) - If the user
	 * trying to perform the action has not logged in.
	 * 
	 * This handler method should map to the URL "/note" using HTTP POST method
	 */
	@PostMapping(value = "/note", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> createNote(@RequestBody Note note, HttpSession session) {
	
		if (session.getAttribute("loggedInUserId") == null)
			return new ResponseEntity<>("Unauthorized user", HttpStatus.UNAUTHORIZED);
		else {
			try {
				String userId = session.getAttribute("loggedInUserId").toString();
				noteService.getNoteById(Integer.parseInt(userId));
				return new ResponseEntity<>("Note creation conflict", HttpStatus.CONFLICT);
			} catch (NumberFormatException numberException) {
				return new ResponseEntity<>(numberException.getMessage(), HttpStatus.BAD_REQUEST);
			}catch (NoteNotFoundException enotfound) {
				try {
					note.setCreatedBy(session.getAttribute("loggedInUserId").toString());
					if (noteService.createNote(note))
						return new ResponseEntity<>(note, HttpStatus.OK);
					else
						return new ResponseEntity<>("Create Note failed", HttpStatus.CONFLICT);
				} catch (ReminderNotFoundException ereminder) {
					return new ResponseEntity<>(ereminder.getMessage(), HttpStatus.BAD_REQUEST);
				} catch (CategoryNotFoundException ecategory) {
					return new ResponseEntity<>(ecategory.getMessage(), HttpStatus.BAD_REQUEST);
				}
			} 
		}
	}

	/*
	 * Define a handler method which will delete a note from a database.
	 * 
	 * This handler method should return any one of the status messages basis on
	 * different situations: 1. 200(OK) - If the note deleted successfully from
	 * database. 2. 404(NOT FOUND) - If the note with specified noteId is not found.
	 * 3. 401(UNAUTHORIZED) - If the user trying to perform the action has not
	 * logged in.
	 * 
	 * This handler method should map to the URL "/note/{id}" using HTTP Delete
	 * method" where "id" should be replaced by a valid noteId without {}
	 */
	@DeleteMapping(value = "/note/{id}")
	public ResponseEntity<String> deleteNote(@RequestParam(value="noteId", required = true) String noteId, HttpSession session) {
	
		if (session.getAttribute("loggedInUserId") == null)
			return new ResponseEntity<>("Unauthorized user", HttpStatus.UNAUTHORIZED);
		else {
			try {
				noteService.getNoteById(Integer.parseInt(noteId));
				if (noteService.deleteNote(Integer.parseInt(noteId)))
					return new ResponseEntity<>("Note deleted successfully", HttpStatus.OK);
				else
					return new ResponseEntity<>("Note delete failed", HttpStatus.NOT_FOUND);
			} catch (NoteNotFoundException e) {
				return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
			} catch (NumberFormatException numberException) {
				return new ResponseEntity<>(numberException.getMessage(), HttpStatus.BAD_REQUEST);
			}
		}
	}
	
	/*
	 * Define a handler method which will update a specific note by reading the
	 * Serialized object from request body and save the updated note details in a
	 * note table in database handle ReminderNotFoundException,
	 * NoteNotFoundException, CategoryNotFoundException as well. please note that
	 * the loggedIn userID should be taken as the createdBy for the note. This
	 * handler method should return any one of the status messages basis on
	 * different situations: 1. 200(OK) - If the note updated successfully. 2.
	 * 404(NOT FOUND) - If the note with specified noteId is not found. 3.
	 * 401(UNAUTHORIZED) - If the user trying to perform the action has not logged
	 * in.
	 * 
	 * This handler method should map to the URL "/note/{id}" using HTTP PUT method.
	 */
	@PutMapping(value = "/note", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> updateNote(@RequestBody Note note, HttpSession session) {
	
		if (session.getAttribute("loggedInUserId") == null)
			return new ResponseEntity<>("Unauthorized user", HttpStatus.UNAUTHORIZED);
		else {
			try {
				//getNoteById returns non-null or throws an exception
				noteService.getNoteById(note.getNoteId());

				note.setCreatedBy(session.getAttribute("loggedInUserId").toString());
				noteService.updateNote(note, note.getNoteId());

				return new ResponseEntity<>(note, HttpStatus.OK);
				
			} catch (NoteNotFoundException enotfound) {
				return new ResponseEntity<>(enotfound.getMessage(), HttpStatus.NOT_FOUND);
			} catch (ReminderNotFoundException ereminder) {
				return new ResponseEntity<>(ereminder.getMessage(), HttpStatus.BAD_REQUEST);
			} catch (CategoryNotFoundException ecategory) {
				return new ResponseEntity<>(ecategory.getMessage(), HttpStatus.BAD_REQUEST);
			}
		}
	}
	/*
	 * Define a handler method which will get us the notes by a userId.
	 * 
	 * This handler method should return any one of the status messages basis on
	 * different situations: 1. 200(OK) - If the note found successfully. 2.
	 * 401(UNAUTHORIZED) -If the user trying to perform the action has not logged
	 * in.
	 * 
	 * 
	 * This handler method should map to the URL "/note" using HTTP GET method
	 */
	@GetMapping(value = "/note", produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<Object> getNoteByUserId(@RequestBody Note note, HttpSession session) {
	
		if (session.getAttribute("loggedInUserId") == null)
			return new ResponseEntity<>("Unauthorized user", HttpStatus.UNAUTHORIZED);
		else {
			String userId = session.getAttribute("loggedInUserId").toString();
			List<Note> notes = noteService.getAllNotesByUserId(userId);
			return new ResponseEntity<>(notes, HttpStatus.OK);
		}
	}
}
